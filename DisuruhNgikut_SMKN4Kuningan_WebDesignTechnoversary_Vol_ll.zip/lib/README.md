Chart.js dimuat dari CDN (jsDelivr, v4.4.1). Untuk mode offline, taruh `chart.umd.min.js` (v4.4.1) di folder ini; index.html otomatis memakainya jika CDN gagal.
